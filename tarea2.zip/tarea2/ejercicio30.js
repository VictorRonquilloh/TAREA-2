//Pide al usuario el total de su cuenta en un restaurante y el porcentaje de descuento
//que ofrece por ser cliente frecuente. Si el total de la cuenta supera los $70, aplica el
//descuento por fidelidad, de lo contrario, no se aplica ningún descuento. Calcula y
//muestra el monto final con el descuento aplicado más el IVA del 15%
// Solicitar al usuario el total de su cuenta en un restaurante.
// Verificar si el total de la cuenta supera los $70.
// Si el total de la cuenta supera los $70, solicitar al usuario el porcentaje de descuento como cliente frecuente.
// Aplicar el descuento proporcionado por el cliente frecuente al total de la cuenta.
// Calcular el monto final con el descuento aplicado.
// Calcular el 15% del IVA sobre el monto final.
// Sumar el IVA al monto final para obtener el monto total a pagar.
// Mostrar el monto total a pagar al usuario.
const read = require('prompt-sync')()
const write = console.log
function calcularMontoFinalRestaurante(totalCuenta, descuentoFidelidad) {
    if (totalCuenta > 70) {
        let montoDescuento = totalCuenta * descuentoFidelidad / 100;
        let montoFinal = totalCuenta - montoDescuento;
        return montoFinal * 0.15; // 15% de IVA
    } else {
        return totalCuenta * 0.15; // 15% de IVA
    }
}

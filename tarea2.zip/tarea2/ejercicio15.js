// Pedir al usuario dos números y mostrar si son iguales o diferente
//Solicitar al usuario dos números.
// Convertir los números ingresados a tipos numéricos.
// Verificar si los dos números son iguales o diferentes.
const read = require('prompt-sync')()
const write = console.log
function sonIgualesODiferentes(num1, num2) {
    if (num1 === num2) {
        return "iguales"
    } else {
        return "diferentes"
    }
}


// Calculadora de sueldo con aumento: Pide al usuario que ingrese su salario actual y el
//porcentaje de aumento que recibirá. Calcula y muestra el nuevo salario después del
//aumento.
//Pedir al usuario que ingrese su salario actual y el porcentaje de aumento que recibirá.
//Calcular el nuevo salario después del aumento.
//Mostrar el nuevo salario.
const read = require('prompt-sync')()
const write = console.log
let salarioActual = parseFloat(prompt("Ingrese su salario actual:"))
let aumentoPorcentaje = parseFloat(prompt("Ingrese el porcentaje de aumento (%):"))
let aumento = salarioActual * (aumentoPorcentaje / 100)
let nuevoSalario = salarioActual + aumento
console.log("Su salario después del aumento es:", nuevoSalario)


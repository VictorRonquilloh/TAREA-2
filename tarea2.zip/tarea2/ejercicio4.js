// 260 / 12 + 54 % 3 – 85 % 7
//Calcular el resultado de la expresión matemática siguiendo las reglas de precedencia de operadores
//Mostrar el resultado
const read = require('prompt-sync')()
const write = console.log
let resultado =parseInt  (260 / 12 + 54 % 3 - 85 % 7)
console.log("el resultado es" ,resultado)

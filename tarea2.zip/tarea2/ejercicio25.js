//Solicitar al usuario el precio de venta de un vehículo nuevo y su año de fabricación.
//Si el año de fabricación está entre el 2020 y 2023, aplicar un descuento del 5% sobre
//el precio de venta. mostrar el precio final incluyendo el 15% del IVA.
// Solicitar al usuario el precio de venta de un vehículo nuevo y su año de fabricación.
// Verificar si el año de fabricación está entre 2020 y 2023.
// Aplicar un descuento del 5% sobre el precio de venta si el año de fabricación está en el rango especificado.
// Calcular el monto final incluyendo el 15% del IVA.
const read = require('prompt-sync')()
const write = console.log
function calcularPrecioFinalVehiculo(precio, anioFabricacion) {
    let descuento = (anioFabricacion >= 2020 && anioFabricacion <= 2023) ? 0.05 : 0;
    let precioConDescuento = precio * (1 - descuento);
    return precioConDescuento * 0.15; // 15% de IVA
}


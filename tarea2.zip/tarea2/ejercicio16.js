//Solicitar al usuario un carácter y mostrar si es una vocal o consonante
// Solicitar al usuario un carácter.
// Verificar si el carácter ingresado es una vocal o una consonante.
const read = require('prompt-sync')()
const write = console.log
function esVocalOConsonante(caracter) {
    if (caracter.length !== 1) {
        return "No es un único carácter."
    }
    const vocales = "aeiouAEIOU"
    if (vocales.includes(caracter)) {
        return "vocal"
    } else {
        return "consonante"
    }
}



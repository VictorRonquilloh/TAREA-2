//Escribir un algoritmo que lea cuatro números y determine si el numero 1 es la mitad
//del número 2; Y si el numero 3 es divisor del numero4
//Leer los cuatro números del usuario.
//Verificar si el número 1 es la mitad del número 2.
//Verificar si el número 3 es divisor del número 4.
//Mostrar los resultados de las verificaciones.

let num1 = parseInt(("Ingrese el primer número:"))
let num2 =  parseInt(("Ingrese el segundo número:"))
let num3 =  parseInt(("Ingrese el tercer número:"))
let num4 = parseInt (("Ingrese el cuarto número:"))
let esMitad = num1 === num2 / 2
let esDivisor = num4 % num3 === 0
console.log("¿El primer número es la mitad del segundo número?", esMitad)
console.log("¿El tercer número es divisor del cuarto número?", esDivisor)

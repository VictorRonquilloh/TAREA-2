//Solicitar al usuario un número y mostrar si es divisible por 2 o impar
//Solicitar al usuario un número.
// Verificar si el número es divisible por 2.
// Si el número es divisible por 2, mostrar que es par, de lo contrario, mostrar que es impar.
const read = require('prompt-sync')()
const write = console.log
function esDivisiblePor2OImpar(numero) {
    return numero % 2 === 0 ? "divisible por 2" : "impar";
}




//. Solicitar al usuario el precio de un producto y el porcentaje de descuento aplicado.
//Calcular y mostrar el precio final luego de aplicar el descuento siempre cuando el
//precio sea mayor $100
//Solicitar al usuario el precio de un producto y el porcentaje de descuento aplicado.
// Verificar si el precio del producto es mayor que $100.
// Calcular el precio final aplicando el descuento si el precio es mayor que $100.
const read = require('prompt-sync')()
const write = console.log
function calcularPrecioFinalConDescuento(precio, descuento) {
    if (precio > 100) {
        return precio * (1 - descuento / 100);
    } else {
        return precio;
    }
}

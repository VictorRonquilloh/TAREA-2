//. Pedir al usuario su nota en un examen y determinar si ha aprobado o reprobado,
//considerando que la nota mínima de aprobación es 60 puntos. Si la nota es mayor a
//40 y menor a 60 se queda para recuperación caso contario pierde la materia.
// Solicitar al usuario su nota en un examen.
// Determinar si la nota es mayor o igual a 60 puntos para aprobar.
// Si la nota es mayor o igual a 60, mostrar que ha aprobado.
// Si la nota es menor que 60 y mayor que 40, mostrar que está para recuperación.
// Si la nota es menor o igual a 40, mostrar que ha reprobado.
const read = require('prompt-sync')()
const write = console.log
function evaluarNota(nota) {
    if (nota >= 60) {
        return "Aprobado";
    } else if (nota >= 40) {
        return "Recuperación";
    } else {
        return "Reprobado";
    }
}

//. Pedir al usuario un número y mostrar si es múltiplo de 3 y par
//Solicitar al usuario un número
// Verificar si el número es múltiplo de 3.
// Verificar si el número es par.
const read = require('prompt-sync')()
const write = console.log
function esMultiploDe3YPar(numero) {
    return numero % 3 === 0 && numero % 2 === 0
}


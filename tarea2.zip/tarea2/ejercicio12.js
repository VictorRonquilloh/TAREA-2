//. Solicitar al usuario su edad y mostrar si es mayor o menor de edad
//Pedir al usuario su edad.
//Comprobar si la edad es mayor o menor de 18 años.
//Mostrar el resultado.
const read = require('prompt-sync')()
const write = console.log
function esMayorDeEdad(edad) {
    return edad >= 18;
}


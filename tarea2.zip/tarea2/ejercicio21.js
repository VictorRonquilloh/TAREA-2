//Solicitar al usuario un número y mostrar si es un número de un solo dígito. 
// Solicitar al usuario un número.
// Verificar si el número tiene un solo dígito.
const read = require('prompt-sync')()
const write = console.log
// Ejercicio 21
function esUnicoDigito(numero) {
    return numero >= 0 && numero < 10;
}



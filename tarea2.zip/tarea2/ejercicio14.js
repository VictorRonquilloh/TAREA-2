//. Solicitar al usuario un número y mostrar si es positivo o negativo
//Pedir al usuario un número.
//Comprobar si el número es positivo, negativo o cero.
//Mostrar el resultado.
const read = require('prompt-sync')()
const write = console.log
function esPositivoONegativo(numero) {
    if (numero > 0) {
        return "positivo"
    } else if (numero < 0) {
        return "negativo"
    } else {
        return "cero"
    }
}


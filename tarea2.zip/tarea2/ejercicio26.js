//6. Pide al usuario el precio de un artículo y el porcentaje de impuesto de ventas aplicado
//en su región. Si el precio del artículo supera los $200, aplica el impuesto de ventas,
//de lo contrario, no se aplica impuesto. Calcula y muestra el precio final luego de
//aplicar el impuesto.
// Solicitar al usuario el precio de un artículo y el porcentaje de impuesto de ventas aplicado en su región.
// Verificar si el precio del artículo supera los $200.
// Si el precio supera los $200, aplicar el impuesto de ventas.
// Calcular y mostrar el precio final luego de aplicar el impuesto, si corresponde.
const read = require('prompt-sync')()
const write = console.log
function calcularPrecioFinalConImpuesto(precio, porcentajeImpuesto) {
    if (precio > 200) {
        return precio * (1 + porcentajeImpuesto / 100);
    } else {
        return precio;
    }
}

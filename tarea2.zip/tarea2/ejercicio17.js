//Pedir dos nombres e indicar si son iguales, si el primer nombre es mayor que el
//segundo o menor que el segundo
// Solicitar dos nombres al usuario.
// Comparar los dos nombres para determinar si son iguales
// Si los nombres son diferentes, comparar su longitud para determinar cuál es mayor.
const read = require('prompt-sync')()
const write = console.log
function compararNombres(nombre1, nombre2) {
    if (nombre1 === nombre2) {
        return "iguales"
    } else if (nombre1.length > nombre2.length) {
        return `${nombre1} es mayor que ${nombre2}`
    } else {
        return `${nombre1} es menor que ${nombre2}`
    }
}

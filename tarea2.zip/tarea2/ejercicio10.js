// El banco POO ha decidido aumentar el límite de crédito de las tarjetas de crédito de
//sus clientes, para esto considera que:
//Si su cliente tiene tarjeta tipo 1, el aumento será del $100 .
//Si tiene tipo 2 el aumento será del $200
//Si tiene tipo 3, el aumento será del $300
//Para cualquier otro tipo será del 500
//Se pide realizar un algoritmo que ayude al banco a determinar el nuevo límite de
//crédito que tendrá una persona en su tarjeta considerando que después del aumento
//se tendrá que subir 10% adicionales a todas las tarjetas
//Pedir al usuario el tipo de tarjeta de crédito (1, 2, 3 u otro).
//Según el tipo de tarjeta, calcular el aumento correspondiente.
//Aplicar un aumento adicional del 10% a todos los tipos de tarjeta.
//Mostrar el nuevo límite de crédito.
const read = require('prompt-sync')()
const write = console.log
function calcularNuevoLimite(tipoTarjeta, aumento) {
    let nuevoLimite;
    switch (tipoTarjeta) {
        case 1:
            nuevoLimite = (100 + aumento) * 1.1;
            break;
        case 2:
            nuevoLimite = (200 + aumento) * 1.1;
            break;
        case 3:
            nuevoLimite = (300 + aumento) * 1.1;
            break;
        default:
            nuevoLimite = (500 + aumento) * 1.1;
    }
    return nuevoLimite;
}
//Pide al usuario el precio total de una compra en una tienda en línea y el cupón de
//descuento a aplicar en porcentaje. Si el precio total de la compra supera los $10,
//aplica el descuento, de lo contrario, no aplica ningún descuento. Calcula y muestra el
//monto final con el descuento con el IVA del 15
// Solicitar al usuario el precio total de una compra en una tienda en línea y el cupón de descuento a aplicar en porcentaje
// Verificar si el precio total de la compra supera los $10
// Si el precio total supera los $10, aplicar el descuento del cupón
// Calcular y mostrar el monto final con el descuento aplicado, incluyendo el 15% del IVA.
const read = require('prompt-sync')()
const write = console
function calcularMontoFinalCompra(precioCompra, descuento) {
    if (precioCompra > 10) {
        let montoDescuento = precioCompra * descuento / 100;
        let montoFinal = precioCompra - montoDescuento;
        return montoFinal * 0.15; // 15% de IVA
    } else {
        return precioCompra;
    }
}

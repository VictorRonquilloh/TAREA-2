//Solicita al usuario su sueldo actual y el porcentaje de incremento salarial anual. Si el
//sueldo actual es menor que 500, aplica el incremento del 5%, de lo contrario, no
//aplica ningún incremento. Calcula y muestra el sueldo esperado con el incremento
//aplicado.
// Solicitar al usuario su sueldo actual y el porcentaje de incremento salarial anual.
// Verificar si el sueldo actual es menor que $500.
// Si el sueldo es menor que $500, aplicar un incremento del 5%.
// Calcular y mostrar el sueldo esperado con el incremento aplicado, si corresponde.
const read = require('prompt-sync')()
const write = console.log
function calcularSueldoConIncremento(sueldoActual, incremento) {
    if (sueldoActual < 500) {
        return sueldoActual * (1 + incremento / 100);
    } else {
        return sueldoActual;
    }
}

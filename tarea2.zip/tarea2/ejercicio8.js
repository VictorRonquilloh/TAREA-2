//que implica pedir al usuario un número y mostrar si es negativo menor que -20, o mostrar si es positivo par o impar múltiplo de 7,
//Pedir al usuario que ingrese un número.
//Verificar si el número es negativo y menor que -20.
//Si no cumple la condición anterior, verificar si es positivo.
//Si es positivo, verificar si es par o impar.
//Si es positivo e impar, verificar si es múltiplo de 7.
//Mostrar el resultado de las verificaciones.
// Paso 1: Pedir al usuario que ingrese un número
const read = require('prompt-sync')()
const write = console.log
let numero = parseFloat(prompt("Ingrese un número:"));
if (numero < -20) {
    console.log("El número es negativo y menor que -20.");
} 
else if (numero >= 0) {
    if (numero % 2 === 0) {
        console.log("El número es positivo y par.")
    } else {
        console.log("El número es positivo e impar.")
        if (numero % 7 === 0) {
            console.log("El número es múltiplo de 7.")
        } else {
            console.log("El número no es múltiplo de 7.")
        }
    }
} 
else {
    console.log("El número es negativo pero no es menor que -20.")
}



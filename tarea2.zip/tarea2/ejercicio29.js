//. Pide al usuario su salario actual y la cantidad de años de antigüedad. Calcule el valor
//del bono de antigüedad del empleado aplicando el 3% del salario por el número de
//años de antigüedad siempre y cuando supere los 3 años, caso contrario el bono de
//antigüedad es de cero. Se pide mostrar el salaria y el bono de antigüedad
// Solicitar al usuario su salario actual y la cantidad de años de antigüedad.
// Verificar si la cantidad de años de antigüedad supera los 3 años.
// Si la antigüedad es mayor que 3 años, calcular el valor del bono de antigüedad como el 3% del salario por el número de años de antigüedad.
// Mostrar el salario y el bono de antigüedad.
const read = require('prompt-sync')()
const write = console.log
function calcularBonoAntiguedad(sueldo, antiguedad) {
    let bono = 0;
    if (antiguedad > 3) {
        bono = sueldo * 0.03 * antiguedad;
    }
    return { sueldo: sueldo, bono: bono };
}

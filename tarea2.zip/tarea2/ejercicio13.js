//Pedir al usuario un número y mostrar si es par o impar
//Pedir al usuario un número.
//Comprobar si el número es par o impar.
//Mostrar el resultado.
const read = require('prompt-sync')()
const write = console.log
function esParOImpar(numero) {
    if (numero % 2 === 0) {
        return "par";
    } else {
        return "impar";
    }
}

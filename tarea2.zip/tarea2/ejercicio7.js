//escribir un algoritmo que lea cuatro números y determine si el número 1 es divisor del número 3, y si el número 2 es el doble del número 4,
//Leer los cuatro números del usuario.
//Verificar si el número 1 es divisor del número 3.
//Verificar si el número 2 es el doble del número 4.
//Mostrar los resultados de las verificaciones.
const read = require('prompt-sync')()
const write = console.log
let num1 = parseFloat(prompt("Ingrese el primer número:"))
let num2 = parseFloat(prompt("Ingrese el segundo número:"))
let num3 = parseFloat(prompt("Ingrese el tercer número:"))
let num4 = parseFloat(prompt("Ingrese el cuarto número:"))
let esDivisor1 = num3 % num1 === 0
let esDoble2 = num2 === num4 * 2
console.log("¿El primer número es divisor del tercer número?", esDivisor1)
console.log("¿El segundo número es el doble del cuarto número?", esDoble2)


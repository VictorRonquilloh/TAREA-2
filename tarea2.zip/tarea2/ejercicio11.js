// Pedir al usuario un número y mostrar si es mayor o menor que 10.
//Pedir al usuario un número.
//Comprobar si el número es mayor o menor que 10.
//Mostrar el resultado.
const read = require('prompt-sync')()
const write = console.log
function esMayorQue10(numero) {
    return numero > 10;
}

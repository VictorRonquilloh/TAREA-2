// para a=8 y b=5,encuentra el valor de v=2*b+a div 2+4*b mod a
//Definir las variables a y b con los valores dados
//Calcular a div 2 (la división entera de a entre 2)
//Calcular b mod a (el residuo de la división de b por a)
//Realizar las operaciones especificadas para obtener el valor de v
//Mostrar el resultado
const read = require('prompt-sync')()
const write = console.log
let a = 8
let b = 5
let a_div_2 = Math.floor(a / 2)
let b_mod_a = b % a
let v = 2 * b + a_div_2 + 4 * b_mod_a
console.log("El valor de v es:", v)

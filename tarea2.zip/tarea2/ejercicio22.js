//Pedir al usuario el monto total de una factura y el año de la compra. Luego, calcular
//y mostrar el monto total a pagar incluyendo el IVA. Si el año de la compra es menor
//al 2024 el porcentaje del IVA es del 12% caso contrario aplicar el IVA del 15%.
// Solicitar al usuario el monto total de una factura y el año de la compra.
// Determinar el porcentaje del IVA a aplicar según el año de la compra.
// Calcular el monto total a pagar incluyendo el IVA.
const read = require('prompt-sync')()
const write = console.log
function calcularTotalConIVA(montoTotal, anioCompra) {
    let porcentajeIVA = anioCompra < 2024 ? 0.12 : 0.15;
    return montoTotal * (1 + porcentajeIVA);
}

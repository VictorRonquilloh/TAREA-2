//(5 + 3 * 2) + 9 > 3 * 5 * 14 %3
//Calcular el resultado de la expresión matemática en ambos lados del operador >
//Comparar los dos resultados para determinar si la condición es verdadera o falsa
//Mostrar el resultado de la comparación
const read = require('prompt-sync')()
const write = console.log
let resultado_izquierdo = (5 + 3 * 2) + 9
let resultado_derecho = 3 * 5 * 14 % 3
let condicion = resultado_izquierdo > resultado_derecho
console.log("¿Es verdadera la condición?", condicion)




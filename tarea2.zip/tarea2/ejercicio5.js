//((8 > 2) || (932 < 23)) && (4 == 2)
//Evaluar las condiciones dentro de los paréntesis y aplicar los operadores lógicos.
//Determinar si la expresión completa es verdadera o falsa.
//Mostrar el resultado.
const read = require('prompt-sync')()
const write = console.log
let resultado = ((8 > 2) || (932 < 23)) && (4 == 2)
console.log("la respuesta es"  ,resultado)

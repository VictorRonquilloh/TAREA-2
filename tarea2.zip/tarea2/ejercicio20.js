//Pedir al usuario un número y mostrar si es mayor 0 y menor o igual a 100
// Solicitar al usuario un número.
// Verificar si el número es mayor que 0.
// Verificar si el número es menor o igual a 100.
const read = require('prompt-sync')()
const write = console.log
function estaEntre0y100(numero) {
    return numero > 0 && numero <= 100;
}


